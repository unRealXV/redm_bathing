return {
    prompt_bath = "Prendre un bain (%s$)",
    prompt_luxury_bath = "Service de luxe (%s$)",
    prompt_scrub = "Frotter",
    prompt_leave = "Sortir du bain",
    notify_not_enough_money = "Tu n'as pas assez d'argent !",
    notify_occupied = "Cette salle est déjà occupée !"
}
