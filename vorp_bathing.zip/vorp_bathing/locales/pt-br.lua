return {
    prompt_bath = "Usar a Banheira (%s$)",
    prompt_luxury_bath = "Serviço de Luxo (%s$)",
    prompt_scrub = "Esfoliar",
    prompt_leave = "Sair",
    notify_not_enough_money = "Você não tem dinheiro suficiente!",
    notify_occupied = "Este quarto está ocupado no momento!"
}
